# Práctica 1 — Django: Proyecto y primera vista
## Arquitectura del Software · UPSA 2025-2026

### Ejecución

py -m venv venv
.\venv\Scripts\activate
pip install django
python manage.py migrate
python manage.py runserver

http://127.0.0.1:8000/app/bienvenida/
http://127.0.0.1:8000/app/saludo/

### URLs disponibles

| URL | Vista |
|-----|-------|
| `/app/bienvenida/` | `views.bienvenida` |
| `/app/saludo/` | `views.saludo` |

### Patrón MVT de Django

- **Model**    → datos y acceso a BBDD
- **View**     → lógica de la petición (equivale al Controlador en MVC clásico)
- **Template** → HTML devuelto al navegador

### Estructura de ramas Git

```
main        → commit inicial del proyecto
develop     → integración semana a semana
feature/primeraApp → esta práctica, parte de develop
```