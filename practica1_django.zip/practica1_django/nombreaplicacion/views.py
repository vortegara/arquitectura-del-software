from django.http import HttpResponse

def bienvenida(request):
    return HttpResponse("¡Hola Mundo! Práctica 1 de Django - Arquitectura del Software")

def saludo(request):
    return HttpResponse("¡Hola desde la segunda vista! El routing de Django funciona correctamente.")

