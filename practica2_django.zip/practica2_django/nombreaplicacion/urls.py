from django.urls import path
from . import views

urlpatterns = [

    path('string/<str:valor>/',   views.string_view,   name='string_view'),

    path('slug/<slug:valor>/',    views.slug_view,     name='slug_view'),

    path('uuid/<uuid:valor>/',    views.uuid_view,     name='uuid_view'),

    path('path/<path:valor>/',    views.path_view,     name='path_view'),

    path('usuario/<int:id>/',     views.obtener_usuario, name='obtener_usuario'),

    path('saludo/<str:nombre>/',  views.saludo,        name='saludo'),

    path('integer/<int:valor>/',  views.integer_view,  name='integer_view'),

    path('validar/',              views.validar_datos, name='validar_datos'),

    path('solo-post/',   views.solo_post,   name='solo_post'),
    path('solo-get/',    views.solo_get,    name='solo_get'),
    path('solo-put/',    views.solo_put,    name='solo_put'),
    path('solo-patch/',  views.solo_patch,  name='solo_patch'),
    path('solo-delete/', views.solo_delete, name='solo_delete'),
]

