import json
import re
import uuid as uuid_lib

from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt

def saludo(request, nombre):
    return HttpResponse(f"Hola, {nombre}!")

def obtener_usuario(request, id):
    return HttpResponse(f"Mostrando información del usuario con ID: {id}")

def string_view(request, valor):
    return HttpResponse(f"String recibido: {valor}")

def integer_view(request, valor):
    return HttpResponse(f"Integer recibido: {valor}")

def slug_view(request, valor):
    return HttpResponse(f"Slug recibido: {valor}")

def uuid_view(request, valor):
    return HttpResponse(f"UUID recibido: {valor}")

def path_view(request, valor):
    return HttpResponse(f"Path recibido: {valor}")

def validar_datos(request):
    try:
        data = request.GET

        string_valor  = data.get('string')
        integer_valor = data.get('integer')
        slug_valor    = data.get('slug')
        uuid_valor    = data.get('uuid')
        path_valor    = data.get('path')
        email_valor   = data.get('email')

        errores = {}

        if string_valor and not re.fullmatch(r'^[A-Za-zÁÉÍÓÚáéíóúÑñ ]+$', string_valor):
            errores['string'] = 'El valor debe contener solo letras y espacios'

        if integer_valor and not integer_valor.isdigit():
            errores['integer'] = 'El valor debe ser un número entero'

        if slug_valor and not re.fullmatch(r'^[a-zA-Z0-9_-]+$', slug_valor):
            errores['slug'] = 'El slug solo puede contener letras, números, guiones y guiones bajos'

        if uuid_valor:
            try:
                uuid_lib.UUID(uuid_valor, version=4)
            except ValueError:
                errores['uuid'] = 'UUID inválido'

        if path_valor and not re.fullmatch(r'^[\w\-/]+$', path_valor):
            errores['path'] = 'El path solo puede contener letras, números, guiones y barras'

        if email_valor and not re.fullmatch(r'^[\w\.-]+@[\w\.-]+\.\w{2,4}$', email_valor):
            errores['email'] = 'Correo electrónico inválido'

        if errores:
            return JsonResponse({'error': errores}, status=400)

        return JsonResponse({'mensaje': 'Todos los datos son válidos'})

    except Exception as e:
        return JsonResponse({'error': f'Error inesperado: {str(e)}'}, status=500)

@csrf_exempt
def solo_post(request):
    if request.method == 'POST':
        return JsonResponse({'mensaje': 'Solicitud POST recibida correctamente'})
    return JsonResponse({'error': 'Método no permitido'}, status=405)

@csrf_exempt
def solo_get(request):
    if request.method == 'GET':
        return JsonResponse({'mensaje': 'Solicitud GET recibida correctamente'})
    return JsonResponse({'error': 'Método no permitido'}, status=405)

@csrf_exempt
def solo_put(request):
    if request.method == 'PUT':
        return JsonResponse({'mensaje': 'Solicitud PUT recibida correctamente'})
    return JsonResponse({'error': 'Método no permitido'}, status=405)

@csrf_exempt
def solo_patch(request):
    if request.method == 'PATCH':
        return JsonResponse({'mensaje': 'Solicitud PATCH recibida correctamente'})
    return JsonResponse({'error': 'Método no permitido'}, status=405)

@csrf_exempt
def solo_delete(request):
    if request.method == 'DELETE':
        return JsonResponse({'mensaje': 'Solicitud DELETE recibida correctamente'})
    return JsonResponse({'error': 'Método no permitido'}, status=405)

