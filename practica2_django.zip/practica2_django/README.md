# Práctica 2 — Django: Parámetros y métodos HTTP
## Arquitectura del Software · UPSA 2025-2026

### Ejecución

py -m venv venv
.\venv\Scripts\activate
pip install django
python manage.py migrate
python manage.py runserver

http://127.0.0.1:8000/app/saludo/Juan/
http://127.0.0.1:8000/app/usuario/5/
http://127.0.0.1:8000/app/string/HolaMundo/
http://127.0.0.1:8000/app/integer/42/
http://127.0.0.1:8000/app/slug/hola-mundo-123/
http://127.0.0.1:8000/app/uuid/123e4567-e89b-12d3-a456-426614174000/
http://127.0.0.1:8000/app/path/mi/carpeta/archivo/
http://127.0.0.1:8000/app/validar/?string=Hola%20Mundo&integer=42&slug=ejemplo-123&uuid=123e4567-e89b-12d3-a456-426614174000&path=mi/carpeta&email=usuario@email.com


### Parte 1 — Path parameters (parámetros en la URL)

| URL | Convertidor | Ejemplo |
|-----|-------------|---------|
| `/app/saludo/<str:nombre>/` | `<str>` | `/app/saludo/Juan/` |
| `/app/integer/<int:valor>/` | `<int>` | `/app/integer/42/` |
| `/app/slug/<slug:valor>/` | `<slug>` | `/app/slug/hola-mundo/` |
| `/app/uuid/<uuid:valor>/` | `<uuid>` | `/app/uuid/123e4567-.../` |
| `/app/path/<path:valor>/` | `<path>` | `/app/path/mi/carpeta/` |
| `/app/usuario/<int:id>/` | `<int>` | `/app/usuario/5/` |

Django valida el tipo automáticamente. Si no coincide devuelve 404.

### Parte 2 — Parámetros en el body (request.GET)

```
GET /app/validar/?string=Hola&integer=42&slug=ejemplo&uuid=123e4567-e89b-12d3-a456-426614174000&path=mi/carpeta&email=user@mail.com
```

Valida manualmente con regex: string (solo letras), integer (solo dígitos), slug, UUID v4, path y email.

### Parte 3 — Control de método HTTP

| URL | Método aceptado |
|-----|----------------|
| `/app/solo-post/` | POST |
| `/app/solo-get/` | GET |
| `/app/solo-put/` | PUT |
| `/app/solo-patch/` | PATCH |
| `/app/solo-delete/` | DELETE |

Cualquier otro verbo devuelve `{"error": "Método no permitido"}` con status 405.
