from django.urls import path
from . import views

urlpatterns = [

    path('clientes/',                          views.lista_clientes,    name='lista_clientes'),
    path('clientes/<int:cliente_id>/',         views.detalle_cliente,   name='detalle_cliente'),
    path('clientes/<int:cliente_id>/coches/',  views.coches_de_cliente, name='coches_de_cliente'),

    path('coches/',                            views.lista_coches,      name='lista_coches'),
    path('coches/<int:coche_id>/',             views.detalle_coche,     name='detalle_coche'),
    path('coches/<int:coche_id>/servicios/',   views.servicios_de_coche, name='servicios_de_coche'),

    path('servicios/',                         views.lista_servicios,   name='lista_servicios'),
]

