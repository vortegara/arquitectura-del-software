from django.http import JsonResponse
from .models import Cliente, Coche, Servicio, CocheServicio

def lista_clientes(request):
    clientes = list(Cliente.objects.values('id', 'nombre', 'telefono', 'email'))
    return JsonResponse(clientes, safe=False)

def detalle_cliente(request, cliente_id):
    try:
        cliente = Cliente.objects.values('id', 'nombre', 'telefono', 'email').get(id=cliente_id)
        return JsonResponse(cliente)
    except Cliente.DoesNotExist:
        return JsonResponse({'error': 'Cliente no encontrado'}, status=404)

def lista_coches(request):
    coches = list(Coche.objects.values('id', 'marca', 'modelo', 'matricula', 'cliente_id'))
    return JsonResponse(coches, safe=False)

def detalle_coche(request, coche_id):
    try:
        coche = Coche.objects.values('id', 'marca', 'modelo', 'matricula', 'cliente_id').get(id=coche_id)
        return JsonResponse(coche)
    except Coche.DoesNotExist:
        return JsonResponse({'error': 'Coche no encontrado'}, status=404)

def coches_de_cliente(request, cliente_id):
    if not Cliente.objects.filter(id=cliente_id).exists():
        return JsonResponse({'error': 'Cliente no encontrado'}, status=404)
    coches = list(Coche.objects.filter(cliente_id=cliente_id).values(
        'id', 'marca', 'modelo', 'matricula'
    ))
    return JsonResponse(coches, safe=False)

def lista_servicios(request):
    servicios = list(Servicio.objects.values('id', 'nombre', 'descripcion'))
    return JsonResponse(servicios, safe=False)

def servicios_de_coche(request, coche_id):
    if not Coche.objects.filter(id=coche_id).exists():
        return JsonResponse({'error': 'Coche no encontrado'}, status=404)
    registros = list(
        CocheServicio.objects
        .filter(coche_id=coche_id)
        .values('servicio__nombre', 'servicio__descripcion', 'fecha')
    )
    return JsonResponse(registros, safe=False)

