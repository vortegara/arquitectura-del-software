# Práctica 3 — Django: ORM y Base de Datos (Taller de Coches)
## Arquitectura del Software · UPSA 2025-2026

### Ejecución

py -m venv venv
.\venv\Scripts\activate
pip install django
python manage.py makemigrations app_gestion_taller
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver

http://127.0.0.1:8000/admin/

http://127.0.0.1:8000/gestion/clientes/
http://127.0.0.1:8000/gestion/clientes/1/
http://127.0.0.1:8000/gestion/clientes/1/coches/
http://127.0.0.1:8000/gestion/coches/
http://127.0.0.1:8000/gestion/coches/1/
http://127.0.0.1:8000/gestion/coches/1/servicios/
http://127.0.0.1:8000/gestion/servicios/

### Modelos y relaciones

```
Cliente ──1:N──► Coche ──N:M──► Servicio
                         │
                   CocheServicio (tabla intermedia, campo 'fecha')
```

| Modelo | Campos clave |
|--------|-------------|
| `Cliente` | nombre, telefono, email |
| `Coche` | cliente (FK→CASCADE), marca, modelo, matricula (unique) |
| `Servicio` | nombre, descripcion, coches (M2M via CocheServicio) |
| `CocheServicio` | coche (FK), servicio (FK), fecha (auto) |

### URLs (JSON)

| URL | Descripción |
|-----|-------------|
| `GET /gestion/clientes/` | Todos los clientes |
| `GET /gestion/clientes/<id>/` | Detalle de un cliente |
| `GET /gestion/clientes/<id>/coches/` | Coches de un cliente |
| `GET /gestion/coches/` | Todos los coches |
| `GET /gestion/coches/<id>/` | Detalle de un coche |
| `GET /gestion/coches/<id>/servicios/` | Servicios de un coche |
| `GET /gestion/servicios/` | Todos los servicios |

### Comandos ORM usados

```python
Cliente.objects.all()
Cliente.objects.values('id', 'nombre', ...).get(id=x)
Coche.objects.filter(cliente_id=x)
CocheServicio.objects.filter(coche=coche).values('servicio__nombre', 'fecha')
```

### Flujo Git

```
main         → commit inicial
develop      → integración
feature/practica3-bbdd → esta práctica
```
