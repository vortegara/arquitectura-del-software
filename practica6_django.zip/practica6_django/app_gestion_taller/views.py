import json
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from .models import Cliente, Coche, Servicio, CocheServicio
from .forms import ClienteForm, CocheForm, ServicioForm, CocheServicioForm

def lista_clientes(request):
    clientes = Cliente.objects.all()
    return render(request, 'app_gestion_taller/lista_clientes.html', {'clientes': clientes})

def detalle_cliente(request, cliente_id):
    cliente = get_object_or_404(Cliente, id=cliente_id)
    coches = Coche.objects.filter(cliente=cliente)
    return render(request, 'app_gestion_taller/detalle_cliente.html', {
        'cliente': cliente,
        'coches': coches,
    })

def nuevo_cliente(request):
    if request.method == 'POST':
        form = ClienteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_clientes')
    else:
        form = ClienteForm()

    return render(request, 'app_gestion_taller/formulario.html', {
        'form': form,
        'titulo': 'Nuevo Cliente',
        'boton': 'Guardar Cliente',
    })

def editar_cliente(request, cliente_id):
    cliente = get_object_or_404(Cliente, id=cliente_id)
    if request.method == 'POST':
        form = ClienteForm(request.POST, instance=cliente)
        if form.is_valid():
            form.save()
            return redirect('detalle_cliente', cliente_id=cliente_id)
    else:
        form = ClienteForm(instance=cliente)

    return render(request, 'app_gestion_taller/formulario.html', {
        'form': form,
        'titulo': f'Editar Cliente: {cliente.nombre}',
        'boton': 'Guardar Cambios',
    })

def eliminar_cliente(request, cliente_id):
    cliente = get_object_or_404(Cliente, id=cliente_id)
    if request.method == 'POST':
        cliente.delete()
        return redirect('lista_clientes')
    return render(request, 'app_gestion_taller/confirmar_eliminar.html', {
        'objeto': cliente,
        'tipo': 'cliente',
        'cancelar_url': 'detalle_cliente',
        'cancelar_id': cliente_id,
    })

def lista_coches(request):
    coches = Coche.objects.select_related('cliente').all()
    return render(request, 'app_gestion_taller/lista_coches.html', {'coches': coches})

def nuevo_coche(request):
    if request.method == 'POST':
        form = CocheForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_coches')
    else:
        form = CocheForm()

    return render(request, 'app_gestion_taller/formulario.html', {
        'form': form,
        'titulo': 'Nuevo Coche',
        'boton': 'Guardar Coche',
    })

def nuevo_coche_para_cliente(request, cliente_id):
    cliente = get_object_or_404(Cliente, id=cliente_id)
    if request.method == 'POST':
        form = CocheForm(request.POST)
        if form.is_valid():
            coche = form.save(commit=False)
            coche.cliente = cliente
            coche.save()
            return redirect('detalle_cliente', cliente_id=cliente_id)
    else:
        form = CocheForm(initial={'cliente': cliente})

    return render(request, 'app_gestion_taller/formulario.html', {
        'form': form,
        'titulo': f'Nuevo Coche para {cliente.nombre}',
        'boton': 'Guardar Coche',
    })

def editar_coche(request, coche_id):
    coche = get_object_or_404(Coche, id=coche_id)
    if request.method == 'POST':
        form = CocheForm(request.POST, instance=coche)
        if form.is_valid():
            form.save()
            return redirect('buscar_servicios_de_coche', coche_id=coche_id)
    else:
        form = CocheForm(instance=coche)

    return render(request, 'app_gestion_taller/formulario.html', {
        'form': form,
        'titulo': f'Editar Coche: {coche.marca} {coche.modelo}',
        'boton': 'Guardar Cambios',
    })

def eliminar_coche(request, coche_id):
    coche = get_object_or_404(Coche, id=coche_id)
    cliente_id = coche.cliente.id
    if request.method == 'POST':
        coche.delete()
        return redirect('detalle_cliente', cliente_id=cliente_id)
    return render(request, 'app_gestion_taller/confirmar_eliminar.html', {
        'objeto': coche,
        'tipo': 'coche',
        'cancelar_url': 'buscar_servicios_de_coche',
        'cancelar_id': coche_id,
    })

def lista_servicios(request):
    servicios = Servicio.objects.all()
    return render(request, 'app_gestion_taller/lista_servicios.html', {'servicios': servicios})

def nuevo_servicio(request):
    if request.method == 'POST':
        form = ServicioForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_servicios')
    else:
        form = ServicioForm()

    return render(request, 'app_gestion_taller/formulario.html', {
        'form': form,
        'titulo': 'Nuevo Servicio',
        'boton': 'Guardar Servicio',
    })

def editar_servicio(request, servicio_id):
    servicio = get_object_or_404(Servicio, id=servicio_id)
    if request.method == 'POST':
        form = ServicioForm(request.POST, instance=servicio)
        if form.is_valid():
            form.save()
            return redirect('lista_servicios')
    else:
        form = ServicioForm(instance=servicio)

    return render(request, 'app_gestion_taller/formulario.html', {
        'form': form,
        'titulo': f'Editar Servicio: {servicio.nombre}',
        'boton': 'Guardar Cambios',
    })

def eliminar_servicio(request, servicio_id):
    servicio = get_object_or_404(Servicio, id=servicio_id)
    if request.method == 'POST':
        servicio.delete()
        return redirect('lista_servicios')
    return render(request, 'app_gestion_taller/confirmar_eliminar.html', {
        'objeto': servicio,
        'tipo': 'servicio',
        'cancelar_url': 'lista_servicios',
        'cancelar_id': None,
    })

def buscar_servicios_de_coche(request, coche_id):
    coche = get_object_or_404(Coche.objects.select_related('cliente'), id=coche_id)
    servicios = (
        CocheServicio.objects
        .filter(coche=coche)
        .select_related('servicio')
        .values('servicio__nombre', 'servicio__descripcion', 'fecha')
    )
    return render(request, 'app_gestion_taller/servicios_coche.html', {
        'coche': coche,
        'servicios': servicios,
    })

def asignar_servicio_a_coche(request, coche_id):
    coche = get_object_or_404(Coche, id=coche_id)
    if request.method == 'POST':
        form = CocheServicioForm(request.POST)
        if form.is_valid():
            registro = form.save(commit=False)
            registro.coche = coche
            registro.save()
            return redirect('buscar_servicios_de_coche', coche_id=coche_id)
    else:
        form = CocheServicioForm(initial={'coche': coche})

    return render(request, 'app_gestion_taller/formulario.html', {
        'form': form,
        'titulo': f'Asignar servicio a {coche.marca} {coche.modelo}',
        'boton': 'Asignar Servicio',
    })

def buscar_coches_de_cliente(request, cliente_id):
    return detalle_cliente(request, cliente_id)

def buscar_coche_matricula(request, matricula):
    coche = get_object_or_404(Coche.objects.select_related('cliente'), matricula=matricula)
    servicios = (
        CocheServicio.objects
        .filter(coche=coche)
        .select_related('servicio')
        .values('servicio__nombre', 'servicio__descripcion', 'fecha')
    )
    return render(request, 'app_gestion_taller/servicios_coche.html', {
        'coche': coche,
        'servicios': servicios,
    })

def buscar_coches_por_servicio(request, servicio_id):
    servicio = get_object_or_404(Servicio, id=servicio_id)
    coches = (
        CocheServicio.objects
        .filter(servicio=servicio)
        .select_related('coche')
        .values('coche__id', 'coche__marca', 'coche__modelo', 'coche__matricula', 'fecha')
    )
    return render(request, 'app_gestion_taller/coches_por_servicio.html', {
        'servicio': servicio,
        'coches': coches,
    })

