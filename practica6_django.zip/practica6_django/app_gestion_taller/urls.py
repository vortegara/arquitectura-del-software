from django.urls import path
from . import views

urlpatterns = [

    path('clientes/',                               views.lista_clientes,              name='lista_clientes'),
    path('clientes/nuevo/',                         views.nuevo_cliente,               name='nuevo_cliente'),
    path('clientes/<int:cliente_id>/',              views.detalle_cliente,             name='detalle_cliente'),
    path('clientes/<int:cliente_id>/editar/',       views.editar_cliente,              name='editar_cliente'),
    path('clientes/<int:cliente_id>/eliminar/',     views.eliminar_cliente,            name='eliminar_cliente'),
    path('clientes/<int:cliente_id>/coches/',       views.buscar_coches_de_cliente,    name='buscar_coches_de_cliente'),
    path('clientes/<int:cliente_id>/coches/nuevo/', views.nuevo_coche_para_cliente,    name='nuevo_coche_para_cliente'),

    path('coches/',                                 views.lista_coches,                name='lista_coches'),
    path('coches/nuevo/',                           views.nuevo_coche,                 name='nuevo_coche'),
    path('coches/matricula/<str:matricula>/',        views.buscar_coche_matricula,      name='buscar_coche_por_matricula'),
    path('coches/<int:coche_id>/',                  views.buscar_servicios_de_coche,   name='detalle_coche'),
    path('coches/<int:coche_id>/editar/',           views.editar_coche,                name='editar_coche'),
    path('coches/<int:coche_id>/eliminar/',         views.eliminar_coche,              name='eliminar_coche'),
    path('coches/<int:coche_id>/servicios/',        views.buscar_servicios_de_coche,   name='buscar_servicios_de_coche'),
    path('coches/<int:coche_id>/servicios/nuevo/',  views.asignar_servicio_a_coche,    name='asignar_servicio_a_coche'),

    path('servicios/',                              views.lista_servicios,             name='lista_servicios'),
    path('servicios/nuevo/',                        views.nuevo_servicio,              name='nuevo_servicio'),
    path('servicios/<int:servicio_id>/coches/',     views.buscar_coches_por_servicio,  name='buscar_coches_por_servicio'),
    path('servicios/<int:servicio_id>/editar/',     views.editar_servicio,             name='editar_servicio'),
    path('servicios/<int:servicio_id>/eliminar/',   views.eliminar_servicio,           name='eliminar_servicio'),
]

