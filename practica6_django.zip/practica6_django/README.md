# Práctica 6 — Django: Formularios con ModelForm (CRUD completo)
## Arquitectura del Software · UPSA 2025-2026

### Ejecución 

py -m venv venv
.\venv\Scripts\activate
pip install django
python manage.py migrate
python manage.py runserver

http://127.0.0.1:8000/gestion/clientes/
http://127.0.0.1:8000/gestion/coches/
http://127.0.0.1:8000/gestion/servicios/

### Cambio principal

Los endpoints de registro reemplazan `@csrf_exempt` + `json.loads()` por **ModelForm** con el patrón GET/POST estándar de Django.

| Antes (P4) | Ahora (P6) |
|---|---|
| `@csrf_exempt` | `{% csrf_token %}` en el template |
| `json.loads(request.body)` | `Form(request.POST)` |
| `Cliente.objects.create(...)` | `form.save()` |
| Validación manual | `form.is_valid()` automático |

### Patrón GET/POST con ModelForm

```python
def nueva_entidad(request):
    if request.method == 'POST':
        form = EntidadForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_...')
    else:
        form = EntidadForm()
    return render(request, 'formulario.html', {'form': form})

# Edición (UPDATE en lugar de INSERT)
form = EntidadForm(request.POST, instance=objeto)

# commit=False: modificar antes de guardar
obj = form.save(commit=False)
obj.campo = valor
obj.save()
```

### CRUD completo

| Entidad | Crear | Editar | Eliminar |
|---------|-------|--------|---------|
| Cliente | `POST /gestion/clientes/nuevo/` | `/clientes/<id>/editar/` | `/clientes/<id>/eliminar/` |
| Coche | `POST /gestion/coches/nuevo/` | `/coches/<id>/editar/` | `/coches/<id>/eliminar/` |
| Servicio | `POST /gestion/servicios/nuevo/` | `/servicios/<id>/editar/` | `/servicios/<id>/eliminar/` |
| Asignar servicio | `POST /gestion/coches/<id>/servicios/nuevo/` | — | — |

Ruta especial: `POST /gestion/clientes/<id>/coches/nuevo/` crea un coche pre-asignado al cliente de la URL.

### Formularios (forms.py)

```python
class ClienteForm(forms.ModelForm):
    class Meta:
        model = Cliente
        fields = '__all__'
```

Django lee el modelo, detecta los tipos de campo y genera los inputs HTML automáticamente. `{{ form.as_p }}` en el template renderiza todos los campos.

### Flujo Git

```
main         → commit inicial
develop      → integración
feature/practica6 → esta práctica
```
