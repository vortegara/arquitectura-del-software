# Práctica 5 — Django: Templates HTML
## Arquitectura del Software · UPSA 2025-2026

### Ejecución

py -m venv venv
.\venv\Scripts\activate
pip install django
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver

http://127.0.0.1:8000/gestion/clientes/
http://127.0.0.1:8000/gestion/coches/
http://127.0.0.1:8000/gestion/servicios/

### Cambio principal

Las vistas ya no devuelven `JsonResponse` sino `render()` con plantillas HTML.

### Configuración necesaria en settings.py

```python
TEMPLATES = [{
    'DIRS': [BASE_DIR / 'templates'],
    ...
}]
```

Crear la carpeta `templates/app_gestion_taller/` en la raíz del proyecto y colocar ahí los archivos `.html`.

### Sintaxis del lenguaje de plantillas Django

```django
{{ variable }}                    → mostrar valor
{{ objeto.campo }}                → acceso a atributo
{% if condicion %}...{% endif %}  → condicional
{% for x in lista %}...{% endfor %}  → bucle
{% url 'nombre_url' param %}      → URL interna (usa el name= del path())
```

### Vistas que devuelven templates

| Vista | Template |
|-------|---------|
| `lista_clientes` | `lista_clientes.html` |
| `detalle_cliente` | `detalle_cliente.html` |
| `lista_coches` | `lista_coches.html` |
| `buscar_servicios_de_coche` | `servicios_coche.html` |
| `lista_servicios` | `lista_servicios.html` |
| `buscar_coches_por_servicio` | `coches_por_servicio.html` |

Los endpoints POST de registro mantienen `JsonResponse` (se migran en práctica 6).

### Flujo Git

```
main         → commit inicial
develop      → integración
feature/practica5 → esta práctica
```
