import json
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Cliente, Coche, Servicio, CocheServicio

def lista_clientes(request):
    clientes = Cliente.objects.all()

    return render(request, 'app_gestion_taller/lista_clientes.html', {'clientes': clientes})

def detalle_cliente(request, cliente_id):
    try:
        cliente = Cliente.objects.get(id=cliente_id)
        coches = Coche.objects.filter(cliente=cliente)
        contexto = {
            'cliente': cliente,
            'coches': coches,
        }
        return render(request, 'app_gestion_taller/detalle_cliente.html', contexto)
    except Cliente.DoesNotExist:
        return render(request, 'app_gestion_taller/detalle_cliente.html',
                      {'error': 'Cliente no encontrado'}, status=404)

def lista_coches(request):
    coches = Coche.objects.select_related('cliente').all()
    return render(request, 'app_gestion_taller/lista_coches.html', {'coches': coches})

def buscar_servicios_de_coche(request, coche_id):
    try:
        coche = Coche.objects.select_related('cliente').get(id=coche_id)
        servicios = (
            CocheServicio.objects
            .filter(coche=coche)
            .select_related('servicio')
            .values('servicio__nombre', 'servicio__descripcion', 'fecha')
        )
        contexto = {
            'coche': coche,
            'servicios': servicios,
        }
        return render(request, 'app_gestion_taller/servicios_coche.html', contexto)
    except Coche.DoesNotExist:
        return render(request, 'app_gestion_taller/servicios_coche.html',
                      {'error': 'Coche no encontrado'}, status=404)

def lista_servicios(request):
    servicios = Servicio.objects.all()
    return render(request, 'app_gestion_taller/lista_servicios.html', {'servicios': servicios})

def buscar_coches_por_servicio(request, servicio_id):
    try:
        servicio = Servicio.objects.get(id=servicio_id)
        coches = (
            CocheServicio.objects
            .filter(servicio=servicio)
            .select_related('coche')
            .values('coche__id', 'coche__marca', 'coche__modelo', 'coche__matricula', 'fecha')
        )
        contexto = {
            'servicio': servicio,
            'coches': coches,
        }
        return render(request, 'app_gestion_taller/coches_por_servicio.html', contexto)
    except Servicio.DoesNotExist:
        return render(request, 'app_gestion_taller/coches_por_servicio.html',
                      {'error': 'Servicio no encontrado'}, status=404)

def buscar_coches_de_cliente(request, cliente_id):
    return detalle_cliente(request, cliente_id)

def buscar_cliente(request, cliente_id):
    return detalle_cliente(request, cliente_id)

@csrf_exempt
def registrar_cliente(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            cliente = Cliente.objects.create(
                nombre=data['nombre'],
                telefono=data['telefono'],
                email=data['email'],
            )
            return JsonResponse({'mensaje': 'Cliente registrado con éxito', 'cliente_id': cliente.id})
        except KeyError:
            return JsonResponse({'error': 'Datos incompletos: nombre, telefono y email son obligatorios'}, status=400)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)
    return JsonResponse({'error': 'Método no permitido'}, status=405)

@csrf_exempt
def registrar_coche(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            cliente = Cliente.objects.get(id=data['cliente_id'])
            coche = Coche.objects.create(
                cliente=cliente,
                marca=data['marca'],
                modelo=data['modelo'],
                matricula=data['matricula'],
            )
            return JsonResponse({'mensaje': 'Coche registrado con éxito', 'coche_id': coche.id})
        except Cliente.DoesNotExist:
            return JsonResponse({'error': 'Cliente no encontrado'}, status=404)
        except KeyError:
            return JsonResponse({'error': 'Datos incompletos: cliente_id, marca, modelo y matricula son obligatorios'}, status=400)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)
    return JsonResponse({'error': 'Método no permitido'}, status=405)

@csrf_exempt
def registrar_servicio(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            coche = Coche.objects.get(id=data['coche_id'])
            servicio = Servicio.objects.create(
                nombre=data['nombre'],
                descripcion=data['descripcion'],
            )
            CocheServicio.objects.create(coche=coche, servicio=servicio)
            return JsonResponse({'mensaje': 'Servicio registrado con éxito', 'servicio_id': servicio.id})
        except Coche.DoesNotExist:
            return JsonResponse({'error': 'Coche no encontrado'}, status=404)
        except KeyError:
            return JsonResponse({'error': 'Datos incompletos: coche_id, nombre y descripcion son obligatorios'}, status=400)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)
    return JsonResponse({'error': 'Método no permitido'}, status=405)

def buscar_coche_matricula(request, matricula):
    try:
        coche = Coche.objects.select_related('cliente').get(matricula=matricula)
        servicios = (
            CocheServicio.objects
            .filter(coche=coche)
            .select_related('servicio')
            .values('servicio__nombre', 'servicio__descripcion', 'fecha')
        )
        contexto = {'coche': coche, 'servicios': servicios}
        return render(request, 'app_gestion_taller/servicios_coche.html', contexto)
    except Coche.DoesNotExist:
        return render(request, 'app_gestion_taller/servicios_coche.html',
                      {'error': 'Coche no encontrado'}, status=404)

