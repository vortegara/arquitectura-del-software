# Práctica 2 — FastAPI + SQLAlchemy (BBDD y Relaciones)
## Arquitectura del Software · UPSA 2025-2026

### Ejecución 

py -m venv venv
.\venv\Scripts\activate
pip install fastapi uvicorn sqlalchemy aiosqlite
python init_db.py
uvicorn main:app --reload

### Estructura del proyecto

```
fastapi_practica2/
├── database.py      → motor SQLAlchemy async + sesión
├── models.py        → tablas ORM con relaciones 1:N y N:M
├── schemas.py       → modelos Pydantic (validación + serialización)
├── dependencies.py  → inyección de sesión de BBDD por petición
├── init_db.py       → crea las tablas (ejecutar una vez)
└── main.py          → endpoints FastAPI
```

### Relaciones implementadas

```
Categoria ──1:N──► Item ──N:M──► Tag
                         │
                   item_tag (tabla intermedia automática)
```

### Endpoints y cURL

```bash
# Crear categoría
curl -X POST "http://127.0.0.1:8000/categorias/" \
     -H "Content-Type: application/json" \
     -d '{"nombre": "Periféricos"}'

# Crear item en categoría 1 (relación 1:N)
curl -X POST "http://127.0.0.1:8000/categorias/1/items/" \
     -H "Content-Type: application/json" \
     -d '{"nombre": "Teclado Mecánico", "precio": 85.50}'

# Listar items (con categoría y tags)
curl -X GET "http://127.0.0.1:8000/items/"

# Crear tag
curl -X POST "http://127.0.0.1:8000/tags/" \
     -H "Content-Type: application/json" \
     -d '{"nombre": "Gaming"}'

# Asignar tag 1 al item 1 (escribe en tabla intermedia item_tag)
curl -X POST "http://127.0.0.1:8000/items/1/tags/1"

# Desasignar tag
curl -X DELETE "http://127.0.0.1:8000/items/1/tags/1"

# Actualizar item
curl -X PUT "http://127.0.0.1:8000/items/1" \
     -H "Content-Type: application/json" \
     -d '{"nombre": "Teclado RGB", "precio": 95.00, "en_stock": true}'

# Eliminar item
curl -X DELETE "http://127.0.0.1:8000/items/1"
```

