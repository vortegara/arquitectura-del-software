from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload

import models
import schemas
from database import engine, Base
from dependencies import get_db

app = FastAPI(
    title="Práctica 2 — FastAPI + SQLAlchemy",
    description="CRUD completo con relaciones 1:N (Categoria→Item) y N:M (Item↔Tag)",
    version="2.0.0",
)

@app.get("/categorias/", response_model=list[schemas.CategoriaResponse], tags=["Categorias"])
async def listar_categorias(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(models.Categoria))
    return result.scalars().all()

@app.post("/categorias/", response_model=schemas.CategoriaResponse, status_code=201, tags=["Categorias"])
async def crear_categoria(cat: schemas.CategoriaCreate, db: AsyncSession = Depends(get_db)):
    nueva = models.Categoria(nombre=cat.nombre)
    db.add(nueva)
    await db.commit()
    await db.refresh(nueva)
    return nueva

@app.get("/categorias/{cat_id}", response_model=schemas.CategoriaResponse, tags=["Categorias"])
async def obtener_categoria(cat_id: int, db: AsyncSession = Depends(get_db)):
    cat = await db.get(models.Categoria, cat_id)
    if not cat:
        raise HTTPException(status_code=404, detail="Categoría no encontrada")
    return cat

@app.delete("/categorias/{cat_id}", tags=["Categorias"])
async def eliminar_categoria(cat_id: int, db: AsyncSession = Depends(get_db)):
    cat = await db.get(models.Categoria, cat_id)
    if not cat:
        raise HTTPException(status_code=404, detail="Categoría no encontrada")
    await db.delete(cat)
    await db.commit()
    return {"mensaje": f"Categoría '{cat.nombre}' eliminada"}

@app.get("/items/", response_model=list[schemas.ItemResponse], tags=["Items"])
async def listar_items(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(models.Item)
        .options(
            selectinload(models.Item.categoria),
            selectinload(models.Item.tags),
        )
    )
    items = result.scalars().all()

    respuesta = []
    for item in items:
        respuesta.append(schemas.ItemResponse(
            id=item.id,
            nombre=item.nombre,
            descripcion=item.descripcion,
            precio=item.precio,
            en_stock=item.en_stock,
            categoria=item.categoria.nombre if item.categoria else None,
            tags=[schemas.TagResponse(id=t.id, nombre=t.nombre) for t in item.tags],
        ))
    return respuesta

@app.post(
    "/categorias/{cat_id}/items/",
    response_model=schemas.ItemResponse,
    status_code=201,
    tags=["Items"],
)
async def crear_item(
    cat_id: int,
    item: schemas.ItemCreate,
    db: AsyncSession = Depends(get_db),
):
    cat = await db.get(models.Categoria, cat_id)
    if not cat:
        raise HTTPException(status_code=404, detail="Categoría no encontrada")

    nuevo = models.Item(**item.dict(), categoria_id=cat_id)
    db.add(nuevo)
    await db.commit()
    await db.refresh(nuevo)

    return schemas.ItemResponse(
        id=nuevo.id,
        nombre=nuevo.nombre,
        descripcion=nuevo.descripcion,
        precio=nuevo.precio,
        en_stock=nuevo.en_stock,
        categoria=cat.nombre,
        tags=[],
    )

@app.get("/items/{item_id}", response_model=schemas.ItemResponse, tags=["Items"])
async def obtener_item(item_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(models.Item)
        .where(models.Item.id == item_id)
        .options(
            selectinload(models.Item.categoria),
            selectinload(models.Item.tags),
        )
    )
    item = result.scalar_one_or_none()
    if not item:
        raise HTTPException(status_code=404, detail="Item no encontrado")

    return schemas.ItemResponse(
        id=item.id,
        nombre=item.nombre,
        descripcion=item.descripcion,
        precio=item.precio,
        en_stock=item.en_stock,
        categoria=item.categoria.nombre if item.categoria else None,
        tags=[schemas.TagResponse(id=t.id, nombre=t.nombre) for t in item.tags],
    )

@app.put("/items/{item_id}", response_model=schemas.ItemResponse, tags=["Items"])
async def actualizar_item(
    item_id: int,
    item_data: schemas.ItemCreate,
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(models.Item)
        .where(models.Item.id == item_id)
        .options(selectinload(models.Item.categoria), selectinload(models.Item.tags))
    )
    db_item = result.scalar_one_or_none()
    if not db_item:
        raise HTTPException(status_code=404, detail="Item no encontrado")

    for campo, valor in item_data.dict().items():
        setattr(db_item, campo, valor)

    await db.commit()
    await db.refresh(db_item)

    return schemas.ItemResponse(
        id=db_item.id,
        nombre=db_item.nombre,
        descripcion=db_item.descripcion,
        precio=db_item.precio,
        en_stock=db_item.en_stock,
        categoria=db_item.categoria.nombre if db_item.categoria else None,
        tags=[schemas.TagResponse(id=t.id, nombre=t.nombre) for t in db_item.tags],
    )

@app.delete("/items/{item_id}", tags=["Items"])
async def eliminar_item(item_id: int, db: AsyncSession = Depends(get_db)):
    item = await db.get(models.Item, item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Item no encontrado")
    await db.delete(item)
    await db.commit()
    return {"mensaje": f"Item '{item.nombre}' eliminado"}

@app.get("/tags/", response_model=list[schemas.TagResponse], tags=["Tags"])
async def listar_tags(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(models.Tag))
    return result.scalars().all()

@app.post("/tags/", response_model=schemas.TagResponse, status_code=201, tags=["Tags"])
async def crear_tag(tag: schemas.TagCreate, db: AsyncSession = Depends(get_db)):
    nuevo = models.Tag(nombre=tag.nombre)
    db.add(nuevo)
    await db.commit()
    await db.refresh(nuevo)
    return nuevo

@app.post("/items/{item_id}/tags/{tag_id}", tags=["Tags"])
async def asignar_tag(item_id: int, tag_id: int, db: AsyncSession = Depends(get_db)):

    res = await db.execute(
        select(models.Item)
        .where(models.Item.id == item_id)
        .options(selectinload(models.Item.tags))
    )
    item = res.scalar_one_or_none()
    if not item:
        raise HTTPException(status_code=404, detail="Item no encontrado")

    tag = await db.get(models.Tag, tag_id)
    if not tag:
        raise HTTPException(status_code=404, detail="Tag no encontrado")

    if tag in item.tags:
        return {"mensaje": "El tag ya estaba asignado a este item"}

    item.tags.append(tag)
    await db.commit()
    return {"mensaje": f"Tag '{tag.nombre}' asignado al item '{item.nombre}'"}

@app.delete("/items/{item_id}/tags/{tag_id}", tags=["Tags"])
async def desasignar_tag(item_id: int, tag_id: int, db: AsyncSession = Depends(get_db)):
    res = await db.execute(
        select(models.Item)
        .where(models.Item.id == item_id)
        .options(selectinload(models.Item.tags))
    )
    item = res.scalar_one_or_none()
    if not item:
        raise HTTPException(status_code=404, detail="Item no encontrado")

    tag = await db.get(models.Tag, tag_id)
    if not tag or tag not in item.tags:
        raise HTTPException(status_code=404, detail="Tag no asignado a este item")

    item.tags.remove(tag)
    await db.commit()
    return {"mensaje": f"Tag '{tag.nombre}' eliminado del item '{item.nombre}'"}

