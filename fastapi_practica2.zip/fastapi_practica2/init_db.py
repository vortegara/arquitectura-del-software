import asyncio
from database import engine, Base
import models

async def init_db():
    async with engine.begin() as conn:

        await conn.run_sync(Base.metadata.create_all)
    print("✓ Base de datos inicializada correctamente.")
    print("  Tablas creadas: categorias, items, tags, item_tag")

if __name__ == "__main__":
    asyncio.run(init_db())

