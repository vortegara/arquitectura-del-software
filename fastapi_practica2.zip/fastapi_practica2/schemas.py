from pydantic import BaseModel

class TagBase(BaseModel):
    nombre: str

class TagCreate(TagBase):
    pass

class TagResponse(TagBase):
    id: int

    class Config:
        from_attributes = True

class CategoriaBase(BaseModel):
    nombre: str

class CategoriaCreate(CategoriaBase):
    pass

class CategoriaResponse(CategoriaBase):
    id: int

    class Config:
        from_attributes = True

class ItemBase(BaseModel):
    nombre: str
    descripcion: str | None = None
    precio: float
    en_stock: bool = True

class ItemCreate(ItemBase):
    pass

class ItemResponse(ItemBase):
    id: int
    categoria: str | None = None
    tags: list[TagResponse] = []

    class Config:
        from_attributes = True

