from sqlalchemy import Column, Integer, String, Float, Boolean, ForeignKey, Table
from sqlalchemy.orm import relationship
from database import Base

item_tag_association = Table(
    "item_tag",
    Base.metadata,
    Column("item_id", ForeignKey("items.id"),  primary_key=True),
    Column("tag_id",  ForeignKey("tags.id"),   primary_key=True),
)

class Categoria(Base):
    __tablename__ = "categorias"

    id     = Column(Integer, primary_key=True, index=True)
    nombre = Column(String, unique=True, nullable=False)

    items = relationship("Item", back_populates="categoria")

    def __repr__(self):
        return f"<Categoria id={self.id} nombre={self.nombre}>"

class Item(Base):
    __tablename__ = "items"

    id          = Column(Integer, primary_key=True, index=True)
    nombre      = Column(String, index=True, nullable=False)
    descripcion = Column(String, nullable=True)
    precio      = Column(Float, nullable=False)
    en_stock    = Column(Boolean, default=True)

    categoria_id = Column(Integer, ForeignKey("categorias.id"), nullable=True)

    categoria = relationship("Categoria", back_populates="items")

    tags = relationship("Tag", secondary=item_tag_association, back_populates="items")

    def __repr__(self):
        return f"<Item id={self.id} nombre={self.nombre} precio={self.precio}>"

class Tag(Base):
    __tablename__ = "tags"

    id     = Column(Integer, primary_key=True, index=True)
    nombre = Column(String, unique=True, nullable=False)

    items = relationship("Item", secondary=item_tag_association, back_populates="tags")

    def __repr__(self):
        return f"<Tag id={self.id} nombre={self.nombre}>"

