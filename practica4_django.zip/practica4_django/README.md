# Práctica 4 — Django: Endpoints POST y búsquedas ORM
## Arquitectura del Software · UPSA 2025-2026

### Ejecución

py -m venv venv
.\venv\Scripts\activate
pip install django
python manage.py migrate
python manage.py runserver

### Endpoints de registro (POST con JSON en el body)

Probar con Postman o cURL. Header: `Content-Type: application/json`.

```bash
# Registrar cliente
curl -X POST http://127.0.0.1:8000/gestion/clientes/registrar/ \
     -H "Content-Type: application/json" \
     -d '{"nombre": "Juan", "telefono": "600111222", "email": "juan@upsa.es"}'

# Registrar coche
curl -X POST http://127.0.0.1:8000/gestion/coches/registrar/ \
     -H "Content-Type: application/json" \
     -d '{"cliente_id": 1, "marca": "Toyota", "modelo": "Corolla", "matricula": "1234ABC"}'

# Registrar servicio
curl -X POST http://127.0.0.1:8000/gestion/servicios/registrar/ \
     -H "Content-Type: application/json" \
     -d '{"coche_id": 1, "nombre": "Cambio de aceite", "descripcion": "Aceite 5W30"}'
```

### Todas las URLs

| Método | URL | Descripción |
|--------|-----|-------------|
| GET | `/gestion/clientes/` | Todos los clientes |
| GET | `/gestion/clientes/<id>/` | Detalle cliente |
| GET | `/gestion/clientes/<id>/coches/` | Coches de un cliente |
| POST | `/gestion/clientes/registrar/` | Crear cliente |
| GET | `/gestion/coches/` | Todos los coches |
| GET | `/gestion/coches/matricula/<mat>/` | Coche + propietario por matrícula |
| GET | `/gestion/coches/<id>/servicios/` | Servicios de un coche |
| POST | `/gestion/coches/registrar/` | Crear coche |
| GET | `/gestion/servicios/` | Todos los servicios |
| GET | `/gestion/servicios/<id>/coches/` | Coches que han recibido un servicio |
| POST | `/gestion/servicios/registrar/` | Crear servicio |

### ORM — métodos usados

| Método | Equivalente SQL |
|--------|----------------|
| `.objects.create(...)` | INSERT |
| `.objects.get(id=x)` | SELECT WHERE id=x (1 resultado, lanza DoesNotExist si no existe) |
| `.objects.filter(campo=x)` | SELECT WHERE (N resultados) |
| `.objects.all()` | SELECT * |
| `.select_related('fk')` | JOIN eficiente |
| `.values('col1', 'tabla__col2')` | SELECT col1, JOIN.col2 |

### Flujo Git

```
main         → commit inicial
develop      → integración
feature/practica4 → esta práctica
```
