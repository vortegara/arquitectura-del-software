from django.urls import path
from . import views

urlpatterns = [

    path('clientes/',   views.lista_clientes,  name='lista_clientes'),
    path('coches/',     views.lista_coches,    name='lista_coches'),
    path('servicios/',  views.lista_servicios, name='lista_servicios'),

    path('clientes/registrar/',  views.registrar_cliente,  name='registrar_cliente'),
    path('coches/registrar/',    views.registrar_coche,    name='registrar_coche'),
    path('servicios/registrar/', views.registrar_servicio, name='registrar_servicio'),

    path('coches/matricula/<str:matricula>/',          views.buscar_coche_por_matricula, name='buscar_coche_por_matricula'),

    path('clientes/<int:cliente_id>/',                 views.buscar_cliente,             name='buscar_cliente'),
    path('clientes/<int:cliente_id>/coches/',          views.buscar_coches_de_cliente,   name='buscar_coches_de_cliente'),

    path('coches/<int:coche_id>/servicios/',           views.buscar_servicios_de_coche,  name='buscar_servicios_de_coche'),

    path('servicios/<int:servicio_id>/coches/',        views.buscar_coches_por_servicio, name='buscar_coches_por_servicio'),
]

