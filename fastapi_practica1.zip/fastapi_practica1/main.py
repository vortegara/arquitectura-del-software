from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI(
    title="Práctica 1 — Introducción a FastAPI",
    description="API básica con los 4 métodos HTTP: GET, POST, PUT y DELETE",
    version="1.0.0",
)

class Item(BaseModel):
    nombre: str
    descripcion: str | None = None
    precio: float
    en_stock: bool = True

items_db: dict[int, Item] = {}
next_id: int = 1

@app.get("/")
def read_root():
    return {"mensaje": "¡Bienvenido a FastAPI!", "docs": "/docs", "redoc": "/redoc"}

@app.get("/items/")
def list_items():
    return {"items": items_db, "total": len(items_db)}

@app.get("/items/{item_id}")
def get_item(item_id: int):
    if item_id not in items_db:
        raise HTTPException(status_code=404, detail=f"Item {item_id} no encontrado")
    return {"item_id": item_id, "item": items_db[item_id]}

@app.post("/items/", status_code=201)
def create_item(item: Item):
    global next_id
    item_id = next_id
    items_db[item_id] = item
    next_id += 1
    return {"mensaje": "Item creado exitosamente", "item_id": item_id, "item": item}

@app.put("/items/{item_id}")
def update_item(item_id: int, item: Item):
    if item_id not in items_db:
        raise HTTPException(status_code=404, detail=f"Item {item_id} no encontrado")
    items_db[item_id] = item
    return {"mensaje": f"Item {item_id} actualizado", "item_id": item_id, "item": item}

@app.delete("/items/{item_id}")
def delete_item(item_id: int):
    if item_id not in items_db:
        raise HTTPException(status_code=404, detail=f"Item {item_id} no encontrado")
    deleted = items_db.pop(item_id)
    return {"mensaje": f"Item {item_id} eliminado", "item_eliminado": deleted}

