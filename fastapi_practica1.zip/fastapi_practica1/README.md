# Práctica 1 — Introducción a FastAPI
## Arquitectura del Software · UPSA 2025-2026

### Ejecución

py -m venv venv
.\venv\Scripts\activate
pip install fastapi uvicorn
uvicorn main:app --reload

http://127.0.0.1:8000/
http://127.0.0.1:8000/docs
http://127.0.0.1:8000/redoc

### Endpoints

| Método | URL | Descripción |
|--------|-----|-------------|
| GET | `/` | Bienvenida |
| GET | `/items/` | Listar todos los items |
| GET | `/items/{id}` | Obtener item por ID → 404 si no existe |
| POST | `/items/` | Crear item → devuelve 201 + ID |
| PUT | `/items/{id}` | Actualizar item completo |
| DELETE | `/items/{id}` | Eliminar item |

### Modelo Item (body JSON para POST y PUT)

```json
{
    "nombre": "Teclado",
    "descripcion": "Teclado mecánico",
    "precio": 45.99,
    "en_stock": true
}
```

`descripcion` es opcional. `en_stock` es `true` por defecto.

### cURL

```bash
curl -X GET "http://127.0.0.1:8000/items/"

curl -X POST "http://127.0.0.1:8000/items/" \
     -H "Content-Type: application/json" \
     -d '{"nombre": "Teclado", "precio": 45.99}'

curl -X PUT "http://127.0.0.1:8000/items/1" \
     -H "Content-Type: application/json" \
     -d '{"nombre": "Teclado RGB", "precio": 55.50, "en_stock": false}'

curl -X DELETE "http://127.0.0.1:8000/items/1"
```
